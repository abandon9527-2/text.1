#include"game.h"
void menu()
{
	printf("*******************************\n");
	printf("**********1.play***************\n");
	printf("**********2.exit***************\n");
	printf("*******************************\n");
}
void initialize(char board[ROWS][COLS], int rows, int cols, char a)
{
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			board[i][j] = a;
		}
	}
}
void appear(char board[ROWS][COLS], int rows, int cols)
{
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			printf("%c", board[i][j]);
		}
		printf("\n");
	}
}