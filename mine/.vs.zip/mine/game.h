#define _CRT_SECURE_NO_WARNINGS
#define ROW 10
#define COL 10
#define ROWS ROW+2
#define COLS COL+2
//���еü��ϣ���Ȼ������scanf
#include<stdio.h>
void menu();
void initialize(char board[ROWS][COLS], int rows, int cols, char a);
void appear(char board[ROWS][COLS], int rows, int cols);