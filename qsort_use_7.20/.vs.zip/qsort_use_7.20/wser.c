
//��ð�ݺ�����ʵ��
//#include<stdio.h>
//void bubbles_sort(int arr[], int sz)
//{
//	for (int j = 0; j < sz-1; j++)
//	{
//		for (int i = 0; i < sz - 1 - j; i++)
//		{
//			if (arr[i] < arr[i + 1])
//			{
//				int temp = arr[i + 1];
//				arr[i + 1] = arr[i];
//				arr[i] = temp;
//			}
//	}
//	}
//}
//int main()
//{
//	//ʵ��ð������
//	int arr[] = {1,2,3,4,5,6,7,8,9,10};
//	int sz = sizeof(arr) / sizeof(arr[0]);
//	bubbles_sort(arr, sz);
//	for (int i = 0; i < sz; i++)
//	{
//		printf("%d", arr[i]);
//	}
//}
//qsort����ϰʹ��
#include<stdio.h>
#include<stdlib.h>
int cmp_int(void* e1, void* e2)
{
	return *(int*)e2 - *(int*)e1;
}
int cmp_float(void* e1, void* e2)
{
	return (int)(*(float*)e1 - *(float*)e2);
}
int cmp_struct(void* e1, void* e2)
{
	return ((struct a1*)e1)->age - ((struct a1*)e2)->age;
}
struct a1
{
	char name[20];
	short age;
};
int main()
{
	//qsortʵ��ð������
	//int arr[] = { 1,2,3,4,5,6,7,9,8,10 };
	//int sz = sizeof(arr) / sizeof(arr[0]);
	////qsort(�����׵�ַ�����鳤�ȣ�����Ԫ�س��ȣ��Ƚϵĺ���)
	//qsort(arr, sz, sizeof(arr[0]), cmp_int);
	//for (int i = 0; i < sz; i++)
	//{
	//	printf("%d ", arr[i]);
	//}
	



	//qsortʵ��flort��ð�ݺ���
	//float arr[] = { 1.0,2.0,3.0,4.0,5.0,6.0,9.0,10.0 };
	//int sz = sizeof(arr) / sizeof(arr[0]);
	//qsort(arr, sz, sizeof(arr[0]), cmp_float);
	//for (int i = 0; i < sz; i++)
	//{
	//	printf("%f\n", arr[i]);
	//}




	//qsortʵ��struct�ṹ�������
	struct a1 n[] = { {"liming",5},{"wangqiang",10},{"zhangfang",8}};
	int sz = sizeof(n) / sizeof(n[0]);
	qsort(n, sz, sizeof(n[0]), cmp_struct);
}